package col.san.GestionEmpleados.infraestructura.persistencia.entidad;

public class EmpleadoEntidad {
}
